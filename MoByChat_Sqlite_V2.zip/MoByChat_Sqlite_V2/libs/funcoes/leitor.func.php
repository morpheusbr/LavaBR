<?php
require_once ($_SERVER['DOCUMENT_ROOT'].'/config/site.config.php');
function __autoload($classe){
require_once(ROOT_CLASS.$classe.".class.php");
}
