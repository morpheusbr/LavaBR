<?php
require_once (ROOT_INC.'topo.inc.php');
$html.='<center>';
$html.='<h2 class="title">'.Subtitulo().'</h2><br>';
if(VerificaSessao()==true):
header("Location: salas");
die();  
else:
if (CSRF::validate($_POST) AND $_SERVER["REQUEST_METHOD"] == 'POST'):
if(LoginOK($_POST['login'],$_POST['senha'])==true):
if(GravaoSessaoEquipe($_POST['login'],$_POST['senha'])==true):
header("Location: salas");
else:
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'erro.png').'">Erro ao tentar logar entre em contato com o programador do site!';
endif;
else:
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'erro.png').'">O login e senha informados não confere!';
endif;
endif;
$form = new Form('logar');	
$html.= $form->header('logar','POST','logar');
$html.= $form->field('text', 'login', 'Login:', array('width'=>250, 'maxlength'=>60));
$html.= $form->field('password', 'senha', 'Senha:', array('width'=>250, 'maxlength'=>60));
$html.= $form->field('submit', 'Logar');
$html.= $form->close();
endif;
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');