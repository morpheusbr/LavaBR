<?php
require_once (ROOT_INC.'topo.inc.php');
$html.='<center>';
$html.='<h2 class="title">Banido.</h2>';
$html.='Você está banido de nosso site!';
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');