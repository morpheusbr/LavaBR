<?php
require_once (ROOT_INC.'topo.inc.php');
$html.='<center>';
$html.='<h2 class="title">Erro 404.</h2>';
$html.='A Página solicitada não existe';
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');