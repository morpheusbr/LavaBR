<?php
require_once (ROOT_INC.'topo.inc.php');
if(VerificaSessao()):
VerificaBloqueio(MeuID(),$_GET['sala']);
VerificaSenhaSala($_GET['sala']);
$html.=Links();
$html.='<center>';
$html.='<h5 class="title">'.Subtitulo().' - '.NomeSala($_GET['sala']).'</h5>';
EntraChat($_GET['sala']);
RemoverItem('mensagens',@$_GET['msg_id'],@$_GET['acao']);
if (CSRF::validate($_POST) AND $_SERVER["REQUEST_METHOD"] == 'POST'):
if(strlen(utf8_decode($_POST['texto']))<3 OR strlen(utf8_decode($_POST['texto']))>500):
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'erro.png').'">Seu texto deve conter no minimo 3 caracteres e no maximo 500!';
else:
if(EnviarMensagem($_POST['texto'],$_POST['para'],$_POST['pvt'],$_GET['sala'])):	
header("Location: chat?sala={$_GET['sala']}");
else:
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'erro.png').'">Não foi possivel enviar a mensagem';
endif;
endif;
endif;
$db= new SQLite('site');
$db->query("SELECT id,usuario,para,texto,privado,anexo,tempo FROM mensagens WHERE sala_id=? ORDER BY tempo DESC LIMIT 20",array($_GET['sala'])); 
$form = new Form('mensagem');	
$html.= $form->header('mensagem','POST','chat?sala='.$_GET['sala']);
$html.= $form->field('checkbox','pvt', '', array('1'=>'PVT'));
$html.= $form->field('text', 'texto', 'Sua Mensagem', array('width'=>250, 'maxlength'=>250));
$html.=SelecionaPvt($_GET['sala']);
$html.= $form->field('submit', 'Enviar');
$html.= $form->close();
$html.='<a href="chat?sala='.$_GET['sala'].'&tempo='.time().'"><strong><img src="'.$imagecache->cache(URL_IMAGENS.'atualizar.png').'">Atualizar</strong></a><br/><a href="upload?sala='.$_GET['sala'].'"><strong><img src="'.$imagecache->cache(URL_IMAGENS.'upload.png').'">Upload</strong></a>';
$html.='<table class="u-full-width">';
$html.='<thead>';
$html.='<tr>';
$html.='<th></th>';
$html.='<th></th>';
$html.='</tr>';
$html.='</thead>';
$html.='<tbody> ';
while (list($id,$usuario,$para,$texto,$privado,$anexo,$tempo) = $db->fetch('row')) { 
if(Admin(MeuID())):
$del='<a href="chat?sala='.$_GET['sala'].'&msg_id='.$id.'&acao=remover"><strong>[X]</strong></a>';
else:
$del='';
endif;
if(strlen(utf8_decode($anexo))>10):
if(in_array(end(multiexplode(array('.'),$anexo)),array('gif', 'jpg', 'jpeg', 'png'))):
$previ='<img src="'.URL_ARC.$anexo.'" width="150" height="150" /><br/>';
else:
$previ='';
endif;
$link='<br/>'.$previ.'<a href="'.URL_ARC.$anexo.'"><strong>Baixar Anexo</strong></a>';
else:
$link='';
endif;

if($privado>0 AND $para==MeuID()):
$html.='<tr>';
$html.='<td>'.GeraAvatar($usuario).'</td>';
$html.='<td style="background:'.DadosUsuario('cor_fundo',$usuario).';">Ptv de '.GeraApelido($usuario).' para você: <small>'.date("H:i:s",$tempo).'</small><br/><font style="color:'.DadosUsuario('cor_texto',$usuario).';"><div class="quebra">'.Texto($texto).$link.'</font>'.$del.'</td>';
$html.='</tr>';
elseif($privado>0 AND $usuario==MeuID()):
$html.='<tr>';
$html.='<td>'.GeraAvatar($usuario).'</td>';
$html.='<td style="background:'.DadosUsuario('cor_fundo',$usuario).';">Ptv para '.GeraApelido($para).': <small>'.date("H:i:s",$tempo).'</small><br/><font style="color:'.DadosUsuario('cor_texto',$usuario).';"><div class="quebra">'.Texto($texto).$link.'</div></font>'.$del.'</td>';
$html.='</tr>';
else:
if($para>0):
$html.='<tr>';
$html.='<td>'.GeraAvatar($usuario).'</td>';
$html.='<td style="background:'.DadosUsuario('cor_fundo',$usuario).';">'.GeraApelido($usuario).' para '.GeraApelido($para).': <small>'.date("H:i:s",$tempo).'</small><br/><font style="color:'.DadosUsuario('cor_texto',$usuario).';">'.Texto($texto).$link.'</font>'.$del.'</td>';
$html.='</tr>';
else:
$html.='<tr>';
$html.='<td>'.GeraAvatar($usuario).'</td>';
$html.='<td style="background:'.DadosUsuario('cor_fundo',$usuario).';">'.GeraApelido($usuario).' para <strong>Todos</strong>: <small>'.date("H:i:s",$tempo).'</small><br/><font style="color:'.DadosUsuario('cor_texto',$usuario).';">'.Texto($texto).$link.'</font>'.$del.'</td>';
$html.='</tr>';
endif;
endif;    
}
$html.='</tbody>';
$html.='</table>';
$html.='<a href="chat?sala='.$_GET['sala'].'&tempo='.time().'"><strong><img src="'.$imagecache->cache(URL_IMAGENS.'atualizar.png').'">Atualizar</strong></a>';
$form = new Form('mensagem');	
$html.= $form->header('mensagem','POST','chat?sala='.$_GET['sala']);
$html.= $form->field('checkbox','pvt', '', array('1'=>'PVT'));
$html.= $form->field('text', 'texto', 'Sua Mensagem', array('width'=>250, 'maxlength'=>250));
$html.=SelecionaPvt($_GET['sala']);
$html.= $form->field('submit', 'Enviar');
$html.= $form->close();
$html.=Links();
else:
header("Location: entrar");
die();  
endif;
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');