<?php
require_once (ROOT_INC.'topo.inc.php');
if(VerificaSessao()):
RemoverSala($_GET['sala_id'],$_GET['acao']);
$html.='<center>';
$html.='Olá '.GeraApelido(MeuID()).'! Escolha uma sala :)<br/>';
$html.=Links();
$db= new SQLite('site');
$db->query("SELECT nome, id FROM salas WHERE dono=? AND fixa=? ORDER BY nome ASC",array(0,1)); 
$html.='<table class="u-full-width">';
$html.='<thead>';
$html.='<tr>';
$html.='<th><img src="'.$imagecache->cache(URL_IMAGENS.'sala.png').'">Salas Publicas</th>';
$html.='<th><img src="'.$imagecache->cache(URL_IMAGENS.'online.png').'">Online</th>';
$html.='</tr>';
$html.='</thead>';
$html.='<tbody> ';
while (list($nome, $id) = $db->fetch('row')) :
if(Admin(MeuID())):
$del='<a href="salas?sala_id='.$id.'&acao=remover"><strong>[X]</strong></a>';
else:
$del='';
endif; 
$html.='<tr>';
$html.='<td>'.GeraLinkSala(MeuID(),$id,'chat?sala='.$id,$nome).$del.'</td>';
$html.='<td><a href="online?sala='.$id.'">('.OnlineSala($id).')</a></td>';
$html.='</tr>';
endwhile;
$html.='</tbody>';
$html.='</table>';

$db->query("SELECT nome, id FROM salas WHERE dono>? AND fixa=? ORDER BY nome ASC",array(0,0)); 
$html.='<table class="u-full-width">';
$html.='<thead>';
$html.='<tr>';
$html.='<th><img src="'.$imagecache->cache(URL_IMAGENS.'sala.png').'">Salas Privadas</th>';
$html.='<th><img src="'.$imagecache->cache(URL_IMAGENS.'online.png').'">Online</th>';
$html.='</tr>';
$html.='</thead>';
$html.='<tbody> ';
while (list($nome, $id) = $db->fetch('row')) :  
if(Admin(MeuID()) OR DonoSala(MeuID(),$id)):
$del='<a href="salas?sala_id='.$id.'&acao=remover"><strong>[X]</strong></a>';
else:
$del='';
endif; 
$html.='<tr>';
$html.='<td>'.GeraLinkSala(MeuID(),$id,'chat?sala='.$id,$nome).$del.'</td>';
$html.='<td><a href="online?sala='.$id.'">('.OnlineSala($id).')</a></td>';
$html.='</tr>';
endwhile;
$html.='</tbody>';
$html.='</table>';
$html.=Links();
else:
header("Location: entrar");
die();  
endif;
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');