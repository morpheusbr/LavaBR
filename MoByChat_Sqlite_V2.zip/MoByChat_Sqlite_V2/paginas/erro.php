<?php
require_once (ROOT_INC.'topo.inc.php');
$html.='<center>';
$html.='<h2 class="title">Erro Desconhecido.</h2>';
$html.='O sistema se comportou de modo inesperado!';
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');