<?php
require_once (ROOT_INC.'topo.inc.php');
$html.='<center>';
$html.='<h2 class="title">'.Subtitulo().'</h2><br/>';
if(VerificaSessao()==true):
header("Location: salas");
die();  
else:
if (CSRF::validate($_POST) AND $_SERVER["REQUEST_METHOD"] == 'POST'):
if(ApelidoEmUso($_POST['apelido'])>0):
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'erro.png').'">Este apelido já está em uso escolha outro';
elseif(strlen(utf8_decode($_POST['apelido']))<3 OR strlen(utf8_decode($_POST['apelido']))>60):
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'erro.png').'">O Apelido deve ter no minimo 3 caracteres e no maximo 60';
else:
if(GravaoSessao($_POST['apelido'],$_POST['cor_texto'],$_POST['cor_fundo'],$_POST['cor_apelido'])):	
header("Location: salas");
else:
$html.='<img src="'.$imagecache->cache(URL_IMAGENS.'erro.png').'">Não foi possivel entrar no chat';
endif;
endif;
endif;
$form = new Form('chat');	
$html.= $form->header('entrar','POST','entrar');
$html.= $form->field('text', 'apelido', 'Apelido:', array('width'=>250, 'maxlength'=>60));
$html.= $form->field('select', 'cor_texto', 'Cor do Texto:', array('#848484'=>'Cinza','#FF9601'=>'Laranja','#04A201'=>'Verde','#F3FF01'=>'Amarelo','#FF0101'=>'Vermelho', '#2A63FF'=>'Azul','#FF01F7'=>'Rosa'));
$html.= $form->field('select', 'cor_fundo', 'Cor fundo do Texto:', array('#D6D5D5'=>'Cinza Leve','#FFE0C3'=>'Laranja Leve','#A1FFA3'=>'Verde Leve','#FBFFC1'=>'Amarelo Leve','#FFBFBF'=>'Vermelho Leve', '#CCE0FF'=>'Azul Leve','#FCD2FF'=>'Rosa Leve'));
$html.= $form->field('select', 'cor_apelido', 'Cor do Apelido:', array('#848484'=>'Cinza','#FF9601'=>'Laranja','#04A201'=>'Verde','#F3FF01'=>'Amarelo','#FF0101'=>'Vermelho', '#2A63FF'=>'Azul','#FF01F7'=>'Rosa'));
$html.= $form->field('submit', 'Entrar');
$html.= $form->close();
endif;
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');