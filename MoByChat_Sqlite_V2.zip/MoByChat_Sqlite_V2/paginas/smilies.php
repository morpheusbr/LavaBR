<?php
require_once (ROOT_INC.'topo.inc.php');
if(VerificaSessao()):
RemoverItem('smilies',$_GET['sml_id'],$_GET['acao']);
$html.='<center>';
$html.='<h2 class="title">'.Subtitulo().'</h2>';
$html.=Links();
$html.='<table class="u-full-width">';
$html.='<thead>';
$html.='<tr>';
$html.='<th>Smilie</th>';
$html.='<th>Codigo</th>';
$html.='</tr>';
$html.='</thead>';
$html.='<tbody> ';
$db= new SQLite('site');
//A quantidade de valor a ser exibida
$quantidade = 10;
//a pagina atual
$pagina     = (isset($_GET['pagina'])) ? (int)$_GET['pagina'] : 1;
//Calcula a pagina de qual valor será exibido
$inicio     = ($quantidade * $pagina) - $quantidade;
$db->query("SELECT codigo,url FROM smilies ORDER BY codigo ASC LIMIT {$inicio}, {$quantidade}");  
while (list($codigo,$url) = $db->fetch('row')) {  
if(Admin(MeuID())):
$del='<a href="smilies?sml_id='.$id.'&acao=remover"><strong>[X]</strong></a>';
else:
$del='';
endif;
$html.='<tr>';
$html.='<td><img src="'.URL_SML.$url.'"/>'.$del.'</td>';
$html.='<td>'.$codigo.'</td>';
$html.='</tr>';
}
$html.='</tbody>';
$html.='</table>';
$total=$db->value("SELECT COUNT(*) FROM smilies");
$totalPagina= ceil($total/$quantidade);
$exibir = 3;
$anterior  = (($pagina - 1) == 0) ? 1 : $pagina - 1;
$posterior = (($pagina+1) >= $totalPagina) ? $totalPagina : $pagina+1;
$html.='<div class="pagination"><a class="first" href="smilies?pagina=1">&laquo;</a>';
$html.='<a class="prev" href="smilies?pagina='.$anterior.'">&lt;</a>';
for($i = $pagina-$exibir; $i <= $pagina-1; $i++){
if($i > 0)
$html.='<a href="smilies?pagina='.$i.'"> '.$i.' </a>';
}
$html.='<span class="current">'.$pagina.'</span>';
for($i = $pagina+1; $i < $pagina+$exibir; $i++){
if($i <= $totalPagina)
$html.='<a class="current" href="smilies?pagina='.$i.'"> '.$i.' </a>';
}
$html.='<a class="next" href="smilies?pagina='.$posterior.'">&gt;</a>';
$html.='<a class="last" href="smilies?pagina='.$totalPagina.'">&raquo;</a></div>';
$html.=Links();
else:
header("Location: entrar");
die();  
endif;
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');