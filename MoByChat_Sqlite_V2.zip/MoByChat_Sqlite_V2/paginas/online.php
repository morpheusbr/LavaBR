<?php
require_once (ROOT_INC.'topo.inc.php');
if(VerificaSessao()):
$html.='<center>';
$html.='<h2 class="title">'.Subtitulo().'</h2>';
$html.=Links();
$db= new SQLite('site');
if($_GET['sala']>0):
$db->query("SELECT usuario,sala_id FROM online WHERE sala_id=? ORDER BY tempo DESC",array($_GET['sala']));
else:
$db->query("SELECT usuario,sala_id FROM online ORDER BY tempo DESC",array($_GET['sala']));
endif; 
$html.='<table class="u-full-width">';
$html.='<thead>';
$html.='<tr>';
$html.='<th><img src="'.$imagecache->cache(URL_IMAGENS.'online.png').'">Usuario</th>';
$html.='<th><img src="'.$imagecache->cache(URL_IMAGENS.'sala.png').'">Sala</th>';
$html.='</tr>';
$html.='</thead>';
$html.='<tbody> ';
while (list($usuario, $sala_id) = $db->fetch('row')) {  
$html.='<tr>';
$html.='<td>'.GeraApelido($usuario).'</td>';
$html.='<td>'.NomeSala($sala_id).'</td>';
$html.='</tr>';
}
$html.='</tbody>';
$html.='</table>';
$html.=Links();
else:
header("Location: entrar");
die();  
endif;
$html.='</center>';
require_once (ROOT_INC.'rodape.inc.php');