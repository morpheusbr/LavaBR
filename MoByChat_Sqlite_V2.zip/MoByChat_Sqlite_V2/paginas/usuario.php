<?php
require_once (ROOT_INC.'topo.inc.php');
if(VerificaSessao()):
if(strlen(utf8_decode($_GET['id']))>0):
if(Bloquiar($_GET['id'],$_GET['sala'],DadosUsuario('ip',$_GET['id']),DadosUsuario('navegador',$_GET['id']),$_GET['acao'])):
header("Location: chat?sala=".$_GET['sala']);
endif;
$html.=Links();
$html.='<table class="u-full-width">';
$html.='<thead>';
$html.='<tr>';
$html.='<th>Apelido: '.GeraApelido($_GET['id']).'</th>';
$html.='</tr>';
$html.='</thead>';
$html.='<tbody> ';
$html.='<tr>';
$html.='<td><strong>Sexo:</strong> '.GeraSexo($_GET['id']).'</td>';
$html.='</tr>';
if(Admin(MeuID())):
$html.='<tr>';
$html.='<td><strong>IP:</strong> '.DadosUsuario('ip',$_GET['id']).'</td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td><strong>Navegador:</strong> '.DadosUsuario('navegador',$_GET['id']).'</td>';
$html.='</tr>';
endif;
if((Admin(MeuID()) OR DonoSala(MeuID(),$sala)) AND $_GET['sala']>0):
$html.='<tr>';
$html.='<td><a href="usuario?id='.$_GET['id'].'&sala='.$_GET['sala'].'&acao=quicar">Quicar</a></td>';
$html.='</tr>';
$html.='<tr>';
$html.='<td><a href="usuario?id='.$_GET['id'].'&sala='.$_GET['sala'].'&acao=bloq">Bloquiar</a></td>';
$html.='</tr>';
if(Admin(MeuID()) AND $_GET['sala']>0):
$html.='<tr>';
$html.='<td><a href="usuario?id='.$_GET['id'].'&sala='.$_GET['sala'].'&acao=bloqip">Bloquiar IP</a></td>';
$html.='</tr>';
endif;
endif;
if(MeuID()!=$_GET['id'] AND $_GET['sala']>0):
$html.='<tr><td><center>';
$form = new Form('mensagem');	
$html.= $form->header('mensagem','POST','chat?sala='.$_GET['sala']);
$html.= $form->field('checkbox','pvt', '', array('1'=>'PVT'));
$html.= $form->field('text', 'texto', 'Sua Mensagem', array('width'=>250, 'maxlength'=>250));
$html.= $form->field ('hidden', 'para',$_GET['id']);
$html.= $form->field('submit', 'Enviar');
$html.= $form->close();
$html.='</center></td></tr>';
endif;
$html.='</tbody>';
$html.='</table>';
$html.=Links();
else:
header("Location: 404");
endif;
else:
header("Location: entrar");
die();  
endif;
require_once (ROOT_INC.'rodape.inc.php');