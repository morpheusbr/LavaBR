<?php
require_once ($_SERVER['DOCUMENT_ROOT'].'/libs/funcoes/leitor.func.php');
$page = new Pagina (Site('titulo').' - '.Subtitulo());
$page->description (Site('descricao'));
$page->keywords (Site('chave'));
$page->robots (true);
$page->charset (CHARSET);
$page->link (array(
URL_CSS.'estilo.css',
URL_CSS.'normalize.css',
URL_CSS.'skeleton.css',
URL_CSS.'paginacao.css',
URL_CSS.'prettify.css',
URL_ICONES.'favicon.ico',
URL_JS.'jquery.min.js',
URL_JS.'run_prettify.js',
URL_JS.'site.js',
URL_JS.'form.js'));
$page->link ('<link href="//fonts.googleapis.com/css?family=Raleway:400,300,600" rel="stylesheet" type="text/css">');
$page->body ('class="code-snippets-visible"');
$html='<div class="topo"><center><img src="'.URL_IMAGENS.'logo.png"></center></div><div class="container">';
LimpaSite();